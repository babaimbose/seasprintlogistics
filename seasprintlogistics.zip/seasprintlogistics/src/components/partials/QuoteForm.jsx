import React from "react";

const QuoteForm = () => {
  return (
    <>
      {" "}
      <section id="get-a-quote" className="get-a-quote">
        <div className="container" data-aos="fade-up">
          <div className="row g-0">
            <div
              className="col-lg-5 quote-bg"
              style={{ backgroundImage: "url(assets/img/quote-bg.jpg)" }}
            ></div>

            <div className="col-lg-7">
              <form
                action="https://formsubmit.io/send/care@seasprintlogistics.com"
                method="post"
                className="php-email-form"
              >
                <h3>Get a quote</h3>
                <p>Please fill out the form:</p>
                <div className="row gy-4">
                  <div className="col-md-6">
                    <input
                      type="text"
                      name="Loading_place"
                      className="form-control"
                      placeholder="Loading Place"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <input
                      type="text"
                      name="Unloading_Place"
                      className="form-control"
                      placeholder="Unloading Place"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <input
                      type="text"
                      name="Weight"
                      className="form-control"
                      placeholder="Total Weight (kg)"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <input
                      type="text"
                      name="Dimensions"
                      className="form-control"
                      placeholder="Dimensions (cm)"
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <select className="form-select" name="Bulk_type" required>
                      <option value="Bulk Type">Bulk Type</option>
                      <option value="Break Bulk">Break Bulk</option>
                      <option value="Neo Bulk">Neo Bulk</option>
                      <option value="Containerized">Containerized</option>
                    </select>
                  </div>

                  <div className="col-md-6">
                    <select className="form-select" name="Type_of_cargo">
                      <option value="Road">Road</option>
                      <option value="Air">Air</option>
                      <option value="Ocean">Ocean</option>
                    </select>
                  </div>

                  <div className="col-lg-12">
                    <h4>Your Personal Details</h4>
                  </div>

                  <div className="col-md-12">
                    <input
                      type="text"
                      name="Name"
                      className="form-control"
                      placeholder="Name"
                      required
                    />
                  </div>

                  <div className="col-md-12 ">
                    <input
                      type="Email"
                      className="form-control"
                      name="email"
                      placeholder="Email"
                      required
                    />
                  </div>

                  <div className="col-md-12">
                    <input
                      type="text"
                      className="form-control"
                      name="Phone"
                      placeholder="Phone"
                      required
                    />
                  </div>

                  <div className="col-md-12">
                    <textarea
                      className="form-control"
                      name="Message"
                      rows="6"
                      placeholder="Message"
                      required
                    ></textarea>
                  </div>

                  <div className="col-md-12 text-center">
                    <div className="loading">Loading</div>
                    <div className="error-message"></div>
                    <div className="sent-message">
                      Your quote request has been sent successfully. Thank you!
                    </div>

                    <button type="submit">Get a quote</button>
                  </div>
                </div>
              </form>
            </div>
            {/* <!-- End Quote Form --> */}
          </div>
        </div>
      </section>
    </>
  );
};

export default QuoteForm;
