import React from "react";
import { Link } from "react-router-dom";
import ServiceSection from "../partials/ServiceSection";
import AboutSection from "../partials/AboutSection";
import FeaturedServicesSection from "../partials/FeaturedServicesSection";
import FeaturesSection from "../partials/FeaturesSection";
import ScrollUp from "../partials/ScrollUp";
import Maps from "../partials/Maps";
import QuoteForm from "../partials/QuoteForm";

const Home = () => {
  return (
    <>
      {/* Carrousel Starts */}

      <div id="carouselExampleCaptions" className="carousel slide">
        <div className="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="0"
            className="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="3"
            aria-label="Slide 4"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="4"
            aria-label="Slide 5"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="5"
            aria-label="Slide 6"
          ></button>
        </div>
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img
              src="assets/img/By_road_hp_slider.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="assets/img/By_air_hp_slider.jpg"
              class="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="assets/img/By_ship_hp_slider.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="assets/img/By_water_hp_slider.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="assets/img/By_warehouse_hp_slider.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="assets/img/By_warehouse2_hp_slider.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px" }}
            />
            <div className="carousel-caption d-none d-md-block">
              <h1 className="display-4">
                <span className="bg-primary p-2 fw-bold">
                  SEASPRINT LOGISTICS
                </span>
              </h1>
              <h6 className="display-6">
                <span className="bg-primary p-2 ">Your Logistics Partner</span>
              </h6>
            </div>
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      {/* Carousel Ends */}

      {/* <!-- ======= Hero Section ======= --> */}
      {/* <section id="hero" className="hero d-flex align-items-center">
        <div className="container">
          <div className="row gy-4 d-flex justify-content-between">
            <div className="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
              <h2 data-aos="fade-up">Seasprint Logistics</h2>
              <p data-aos="fade-up" data-aos-delay="100">
                Unlock the Power of Seamless Logistics. From transportation to
                warehousing, our integrated solutions drive efficiency,
                reliability, & growth. Experience streamlined operations, timely
                deliveries, & a competitive edge.
              </p>

              <div className="row gy-4" data-aos="fade-up" data-aos-delay="400">
                <div className="col-lg-3 col-6">
                  <div className="stats-item text-center w-100 h-100">
                    <span
                      data-purecounter-start="0"
                      data-purecounter-end="232"
                      data-purecounter-duration="1"
                      className="purecounter"
                    ></span>
                    <p>Clients</p>
                    <h1>400+</h1>
                  </div>
                </div>

                <div className="col-lg-3 col-6">
                  <div className="stats-item text-center w-100 h-100">
                    <span
                      data-purecounter-start="0"
                      data-purecounter-end="521"
                      data-purecounter-duration="1"
                      className="purecounter"
                    ></span>
                    <p>Projects</p>
                    <h1>150+</h1>
                  </div>
                </div>

                <div className="col-lg-3 col-6">
                  <div className="stats-item text-center w-100 h-100">
                    <span
                      data-purecounter-start="0"
                      data-purecounter-end="1453"
                      data-purecounter-duration="1"
                      className="purecounter"
                    ></span>
                    <p>Support</p>
                    <h1>24/7</h1>
                  </div>
                </div>

                <div className="col-lg-3 col-6">
                  <div className="stats-item text-center w-100 h-100">
                    <span
                      data-purecounter-start="0"
                      data-purecounter-end="32"
                      data-purecounter-duration="1"
                      className="purecounter"
                    ></span>
                    <p>Workers</p>
                    <h1>350+</h1>
                  </div>
                </div>
              </div>
            </div>

            <div
              className="col-lg-6 order-1 order-lg-2 hero-img"
              data-aos="zoom-out"
            >
              <img
                src="assets/img/sp-hero.png"
                className="img-fluid mb-3 mb-lg-0"
                alt="logo"
              />
            </div>
          </div>
        </div>
      </section> */}
      {/* <!-- End Hero Section --> */}

      <main id="main">
        {/* <!-- ======= Featured Services Section ======= --> */}
        <FeaturedServicesSection />
        {/* <!-- End Featured Services Section --> */}

        {/* <!-- ======= About Us Section ======= --> */}
        <AboutSection />
        {/* <!-- End About Us Section --> */}

        {/* <!-- ======= Services Section ======= --> */}
        <ServiceSection />
        {/* <!-- End Services Section -->

    <!-- ======= Call To Action Section ======= --> */}
        <section id="call-to-action" className="call-to-action">
          <div className="container" data-aos="zoom-out">
            <div className="row justify-content-center">
              <div className="col-lg-8 text-center">
                <h1 className="text-white">Seasprint Logistics</h1>
                <h3 className="text-white">
                  Let Us Help You To Find A Solution That Meets Your Needs
                </h3>
                <p>
                  For Any Query Mail or Call us, Our representative will be
                  contact you within 24 hours.
                </p>
                <Link className="cta-btn" to="tel: +917303897775">
                  +91 7303897775
                </Link>
                <Link className="cta-btn" to="/contact">
                  Call us Now
                </Link>
              </div>
            </div>
          </div>
        </section>
        {/* <!-- End Call To Action Section -->

    <!-- ======= Features Section ======= --> */}
        <FeaturesSection />
        {/* <!-- End Features Section --> */}

        {/* =========Quote Section======== */}

        <h2 className="text-center">GET A QUOTE</h2>

        <QuoteForm />

        {/* =========End of Quote Section======== */}

        {/* =========Contact section========== */}

        <h2 className="text-center">CONTACT US</h2>

        <Maps />

        {/* =========End of Contact section========== */}
      </main>
      {/* <!-- End #main --> */}
      <ScrollUp />
    </>
  );
};

export default Home;
