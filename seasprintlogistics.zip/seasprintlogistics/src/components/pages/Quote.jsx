import React from "react";
import Breadcrumbs from "../partials/Breadcrumbs";
import QuoteForm from "../partials/QuoteForm";

const Quote = () => {
  return (
    <>
      <main id="main">
        {/* <!-- ======= Breadcrumbs ======= --> */}
        <Breadcrumbs pageTitle={"Get a Quote"} />
        {/* <!-- End Breadcrumbs -->

<!-- ======= Get a Quote Section ======= --> */}
        <QuoteForm />
        {/* <!-- End Get a Quote Section --> */}
      </main>
      {/* <!-- End #main --> */}
    </>
  );
};

export default Quote;
