import React, { useState } from "react";
import Breadcrumbs from "../partials/Breadcrumbs";
import Maps from "../partials/Maps";

const Contact = () => {
  // cosnt[(state, setState)] = useState(() => {
  //   return {
  //     name: "",
  //     email: "",
  //     phone: "",
  //     message: "",
  //   };
  // });

  // const handler = (e) => {
  //   setState(() => {
  //     return {
  //       ...state,
  //       [e.target.name]: e.target.value,
  //     };
  //   });
  // };

  const submission = (e) => {
    e.preventDefault();
  };

  return (
    <>
      <main id="main">
        {<Breadcrumbs pageTitle={"Contact"} />}

        {/*<!-- ======= Contact Section ======= --> */}
        <Maps />
        {/* <!-- End Contact Section --> */}
      </main>
      {/* <!-- End #main --> */}
    </>
  );
};

export default Contact;
